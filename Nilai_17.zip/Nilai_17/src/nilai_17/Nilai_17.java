package nilai_17;

/**
 *
 * @author User
 */
public class Nilai_17 {
     public int getnilaiPengetahuan (int pengetahuan){
        return pengetahuan;
    }

    public int getnilaiKeterampilan (int keterampilan){
        return keterampilan;
    }
    
}